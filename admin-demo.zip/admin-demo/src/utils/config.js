const testUrl = 'https://test.com';
const prodUrl = 'https://test.com';

export const envMap = [
  {
    key: 'develop',
    name: '开发环境',
    url: 'http://test.com:8080',
  },
  {
    key: 'staging',
    name: '测试环境',
    url: 'https://product.com',
  },
];

export const isProd = window.location.hostname === 'admin.test.com';

export const baseUrl = localStorage.getItem('url') || (isProd ? prodUrl : testUrl);

export const formItemLayout = {
  labelCol: { span: 5 },
  wrapperCol: { span: 19 },
};

export const findItem = (list, value, iName, oName, tem) => {
  const item = list.find(c => c[iName] === value);
  return typeof item !== 'undefined' ? item[oName] : tem || '';
};

export const dateFormat = 'YYYY-MM-DD HH:mm:ss';

export const monthFormat = 'YYYYMM';

export const dateDotFormat = 'YYYY.MM.DD';

export const defaultPagination = {
  current: 1,
  pageSize: 10,
};
