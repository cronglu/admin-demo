import Form, { FormItem, FormCore, If, Item } from 'noform';
import {
  Input,
  Select,
  Checkbox,
  Radio,
  Switch,
  Slider,
  DatePicker,
  TimePicker,
  Rate,
  Cascader,
  TreeSelect,
  Modal,
  InputNumber,
  AutoComplete,
} from 'nowrapper/lib/antd';
import { Upload } from 'components';
import { TableRepeater, InlineRepeater, Selectify, ActionButton } from 'nowrapper/lib/antd/repeater';
import Editor from 'components/BraftEditor';
import DialogForm from 'components/DialogForm';

export {
  Form,
  FormItem,
  Item,
  FormCore,
  DialogForm,
  Input,
  Select,
  Checkbox,
  Radio,
  Switch,
  Slider,
  DatePicker,
  TimePicker,
  Rate,
  Cascader,
  TreeSelect,
  Upload,
  Modal,
  InputNumber,
  AutoComplete,
  TableRepeater,
  InlineRepeater,
  Selectify,
  ActionButton,
  Editor,
  If,
};
