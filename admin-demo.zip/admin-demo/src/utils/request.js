import fetch from 'dva/fetch';
import { stringify } from 'qs';
import { message } from 'antd';
import serialize from 'serialize-javascript';
import { router } from 'umi'
import { readPagination } from './utils';
import { baseUrl } from './config';

const codeMessage = {
  200: '服务器成功返回请求的数据。',
  201: '新建或修改数据成功。',
  202: '一个请求已经进入后台排队（异步任务）。',
  204: '删除数据成功。',
  400: '发出的请求有错误，服务器没有进行新建或修改数据的操作。',
  401: '用户没有权限（令牌、用户名、密码错误）。',
  403: '用户得到授权，但是访问是被禁止的。',
  404: '发出的请求针对的是不存在的记录，服务器没有进行操作。',
  406: '请求的格式不可得。',
  410: '请求的资源被永久删除，且不会再得到的。',
  422: '当创建一个对象时，发生一个验证错误。',
  500: '服务器发生错误，请检查服务器。',
  502: '网关错误。',
  503: '服务不可用，服务器暂时过载或维护。',
  504: '网关超时。',
};

async function checkStatus(response, body) {
  if (response.status >= 200 && response.status < 300) {
    const { headers } = response;
    const { errcode: code, errmsg: msg, data } = await response.json();
    console.log(code, "code");

    if (code === 200) {
      let res = data;
      sessionStorage.token = headers.Authorization || sessionStorage.token;
      if (data && data.items && (data.current || data.pageSize || (body && body.noPage))) {
        res = readPagination(data, body);
      }
      return res;
    } else if (code === 401) {
      message.warning("登录过期，请重新登录")
      router.replace("/login")
    } else if (code === '5002') {
      const error = new Error('Excel上传参数错误');
      error.name = code;
      throw error;
    } else {
      const error = new Error(msg);
      error.name = code;
      message.error(msg);
      // throw error;
    }
  } else {
    const error = new Error(codeMessage[response.status] || response.statusText);
    error.name = String(response.status);
    throw error;
  }
}

/**
 * Requests a URL, returning a promise.
 *
 * @param  {string} api       The URL we want to request
 * @param  {object} [options] The options we want to pass to "fetch"
 * @return {object}           An object containing either "data" or "err"
 */
export default async function request(api, options = {}) {
  const defaultOptions = {
    headers: {
      Authorization: sessionStorage.token || '',
    },
    method: 'GET',
  };
  const { rootUrl = baseUrl, params = {}, ...rest } = options;
  const newOptions = { ...defaultOptions, ...rest };

  if (newOptions.method === 'POST' || newOptions.method === 'PUT') {
    if (!(newOptions.body instanceof FormData)) {
      newOptions.headers = {
        Accept: 'application/json',
        'Content-Type': 'application/json;charset=utf-8',
        ...newOptions.headers,
      };
      newOptions.body = serialize(newOptions.body, { isJSON: true });
    } else {
      // newOptions.body is FormData
      newOptions.headers = {
        Accept: 'application/json',
        'Content-Type': 'multipart/form-data',
        ...newOptions.headers,
      };
    }
  }
  const response = await fetch(`${rootUrl}${api}?${stringify(params)}`, newOptions);

  if (rest.noPage) {
    newOptions.body = rest;
  }
  return checkStatus(response, newOptions.body);
}
