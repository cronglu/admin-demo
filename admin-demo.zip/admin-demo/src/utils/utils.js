import moment from 'moment';
import { message } from 'antd';
import XLSX from 'xlsx';
import ExportJsonExcel from 'js-export-excel';

export function fixedZero(val) {
  return val * 1 < 10 ? `0${val}` : val;
}

export function getTimeDistance(type) {
  const now = new Date();
  const oneDay = 1000 * 60 * 60 * 24;

  if (type === 'today') {
    now.setHours(0);
    now.setMinutes(0);
    now.setSeconds(0);
    return [moment(now), moment(now.getTime() + (oneDay - 1000))];
  }

  if (type === 'week') {
    let day = now.getDay();
    now.setHours(0);
    now.setMinutes(0);
    now.setSeconds(0);

    if (day === 0) {
      day = 6;
    } else {
      day -= 1;
    }

    const beginTime = now.getTime() - day * oneDay;

    return [moment(beginTime), moment(beginTime + (7 * oneDay - 1000))];
  }

  if (type === 'month') {
    const year = now.getFullYear();
    const month = now.getMonth();
    const nextDate = moment(now).add(1, 'months');
    const nextYear = nextDate.year();
    const nextMonth = nextDate.month();

    return [
      moment(`${year}-${fixedZero(month + 1)}-01 00:00:00`),
      moment(moment(`${nextYear}-${fixedZero(nextMonth + 1)}-01 00:00:00`).valueOf() - 1000),
    ];
  }

  if (type === 'year') {
    const year = now.getFullYear();

    return [moment(`${year}-01-01 00:00:00`), moment(`${year}-12-31 23:59:59`)];
  }
}

// 获取文件名
export function getFileName(fileUrl) {
  if (fileUrl && typeof fileUrl === 'string') {
    let name = '';
    name = fileUrl.substring(fileUrl.lastIndexOf('/') + 1);
    if (name.indexOf('?') > -1) {
      name = name.slice(0, name.indexOf('?'));
    }
    return name;
  }
}

export function getPlainNode(nodeList, parentPath = '') {
  const arr = [];
  nodeList.forEach(node => {
    const item = node;
    item.path = `${parentPath}/${item.path || ''}`.replace(/\/+/g, '/');
    item.exact = true;
    if (item.children && !item.component) {
      arr.push(...getPlainNode(item.children, item.path));
    } else {
      if (item.children && item.component) {
        item.exact = false;
      }
      arr.push(item);
    }
  });
  return arr;
}

export function readPagination(data, body = '{}') {
  // 用来保存过滤参数
  // const filters = JSON.parse(body);
  console.log(body);
  const { items: list, current, total, pageSize } = data;
  return {
    list,
    pagination: {
      total,
      current,
      pageSize,
    },
  };

  // if (Object.keys(filters).length) {
  //   res.filters = filters;
  // }
  // return res;
}

/*
 * 数组去重
 * */
export function unique(arr, key) {
  if (key) {
    const resObj = {};
    arr.forEach(i => {
      resObj[i[key]] = i;
    });
    return Object.values(resObj);
  } else {
    const initArr = arr.map(i => JSON.stringify(i));
    const resArr = [...new Set(initArr)];
    return resArr.map(i => JSON.parse(i));
  }
}

/**
 *  对象数组根据对象某属性值大小排序
 */
export function compare(property, desc) {
  return (a, b) => {
    const value1 = a[property];
    const value2 = b[property];
    if (desc === true) {
      // 升序排列
      return value1 - value2;
    } else {
      // 降序排列
      return value2 - value1;
    }
  }
}

/*
 * 过滤对象中空值
 * */
export function filterObject(obj) {
  const arr = Object.keys(obj);
  const res = {};
  arr.forEach(e => {
    if (obj[e] || typeof obj[e] === 'number') {
      res[e] = obj[e];
    }
  });
  return res;
}

/**
 * 
 * @param {待检查和转换的数据} obj 
 * @param {目标类型} target
 * 将原始数据转换成对应的数据，赋予初始值 
 */
export function handleNull(obj, target = '') {
  switch (target) {
    case 'boolean':
      return Boolean(obj);
    case 'number':
      return obj ? Number(obj) : 0;
    case 'string':
      return obj ? String(obj) : '';
    case 'undefined':
      return undefined;
    case 'array':
      if (Array.isArray(obj)) {
        return obj.filter(i => i);
      } else {
        return [];
      }
    case 'object':
      if (typeof obj === 'object') {
        return obj;
      } else {
        return {};
      }
    default:
      return undefined;
  }
}

export function newFilters(form) {
  const { rangeTime, ...rest } = form.getValues();

  if (rangeTime) {
    rest.start_time =
      rangeTime[0].set({ hour: 0, minute: 0, second: 0, millisecond: 0 }).valueOf() / 1000;
    rest.end_time =
      rangeTime[1].set({ hour: 23, minute: 59, second: 59, millisecond: 0 }).valueOf() / 1000;
  }
  return filterObject(rest);
}

export function handleUploadToData(value, type = 'string') {
  if (type === 'string') {
    if (Array.isArray(value) && value.length > 0) {
      return value[0].url;
    } else {
      return '';
    }
  } else {
    const imageArr = [];
    if (Array.isArray(value) && value.length > 0) {
      value.forEach(i => {
        imageArr.push(i.url);
      })
    }
    return imageArr;
  }
}

export function dataToUpload(data, from = 'string') {
  const imageArr = [];
  if (from === 'string') {
    if (data && data.toString().length > 0) {
      imageArr.push({
        uid: Math.random().toString(36).slice(2),
        name: getFileName(data),
        status: 'done',
        url: data,
      })
    }
  } else if (from === 'array') {
    if (Array.isArray(data) && data.length > 0) {
      data.forEach(i => {
        imageArr.push({
          uid: Math.random().toString(36).slice(2),
          name: getFileName(i),
          status: 'done',
          url: i,
        })
      })
    }
  }
  return imageArr;
}

// excel to json
export async function parseExcel(file) {
  const fileReader = new FileReader();
  function insertFile() {
    return new Promise(rs => {
      fileReader.onload = ev => {
        let datas = [];
        let data = '';
        let workbook = '';
        try {
          data = ev.target.result;
          workbook = XLSX.read(data, {
            type: 'binary',
          }); // 以二进制流方式读取得到整份excel表格对象
        } catch (e) {
          console.log('文件类型不正确');
          return;
        }
        // 表格的表格范围，可用于判断表头是否数量是否正确
        // 遍历每张表读取
        const { Sheets } = workbook;
        /* eslint-disable */
        for (const sheet in Sheets) {
          if (workbook.Sheets.hasOwnProperty(sheet)) {
            datas = datas.concat(XLSX.utils.sheet_to_json(workbook.Sheets[sheet]));
            // break; // 如果只取第一张表，就取消注释这行
          }
        }
        /* eslint-disable */
        return rs(datas);
      };
      // 以二进制方式打开文件
      fileReader.readAsBinaryString(file);
    });
  }
  return await insertFile(file);
}

export function exportExcel(data, columns, fileName, callback) {
  const option = {};
  option.fileName = fileName;
  option.datas = [
    {
      sheetData: data.map(item => {
        const result = {};
        columns.forEach(c => {
          const curKey = c.key || c.dataIndex;
          result[curKey] = c.render ? c.render(item) : item[curKey];
        });
        return result;
      }),
      sheetName: 'ExcelName', // Excel文件名称
      sheetFilter: columns.map(item => item.dataIndex || item.key),
      sheetHeader: columns.map(item => item.title),
      columnWidths: columns.map(() => 10),
    },
  ];
  const toExcel = new ExportJsonExcel(option);
  toExcel.saveExcel();
  message.success('导出成功！');
  if (callback && typeof callback === 'function') {
    callback();
  }
}
