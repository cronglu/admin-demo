import React, { PureComponent } from 'react';
import { filterObject } from 'utils/utils';
import _ from "lodash";
import { FormCore, Form, FormItem, Select, If } from '../../utils/noform';


const { Option } = Select;

function handlePValue(arrTags) {
  if (_.isArray(arrTags)) {
    if (arrTags.length > 3) {
      const topThreeTag = _.slice(arrTags, 0, 3);
      const tags4 = _.flattenDeep(_.slice(arrTags, 3));
      return [...topThreeTag, tags4];
    } else {
      return arrTags;
    }
  } else {
    return [];
  }
}

// @connect(({ tags }) => ({ ...tags }))
class Tags extends PureComponent {

  constructor(props) {
    super(props);

    const { pCore, value: pValue, callback } = props;  // formItem 相关属性和值
    const pName = props.pName || props.name;
    this.tags = [];
    this.tagsLabel = {};
    this.multiple = props.multiple || { tag3: false, tag4: true }
    this.state = {
      tag4Options: [],
    }
    console.log(pName, pValue, 'pName');

    this.form = new FormCore({
      onChange: (changeKeys, values, core) => {

        if (changeKeys.length !== 3) { // 三个设置不做操作
          if (changeKeys[0] === 'tag1' && values.tag1) {
            this.loadTags(values.tag1, 2);
            core.setValues({ tag2: undefined, tag3: undefined, tag4: undefined })

          } else if (changeKeys[0] === 'tag2' && values.tag2) {
            this.loadTags(values.tag2, 3);
            core.setValues({ 'tag3': undefined, tag4: undefined });
          }
        }

        this.tags = [];
        Object.values(filterObject(core.getValues())).forEach(i => {
          this.tags.push(i);
        })

        pCore.setValue(pName, this.tags);

        if (callback) {
          callback(core);
        }
      },

      initialized: (ctx) => {
        this.loadTags(0, 1);
        // 为了保证顺序渲染，分开赋值
        if (pValue && Array.isArray(pValue) && pValue.length > 0) {
          // 兼容 将1维数组转换成对应的数组
          const tagsArr = handlePValue(pValue);
          console.log(tagsArr, '结果数据');

          this.onChangeByTagIds(ctx, tagsArr);

          this.tags = [];
          Object.values(filterObject(ctx.getValues())).forEach(i => {
            this.tags.push(i);
          })

          pCore.setValue(pName, this.tags);
          console.log(pName, this.tags, pCore.getValues(), 'ppppp');

        } else {
          pCore.setValue(pName, this.tags);
        }
      },
    })
  }

  componentDidUpdate(prevProps) {
    const { value: currentValue } = this.props;
    let preValue = [];

    if (!Array.isArray(prevProps.value)) {
      const { value = [] } = preValue
      const { tag1 = '', tag2 = '', tag3 = '', tag4 = [] } = value;
      preValue = [tag1, tag2, tag3, tag4];
    } else {
      preValue = prevProps.value;
    }

    if (Array.isArray(currentValue) && Array.isArray(preValue)) {
      if (currentValue.join(',') !== preValue.join(',')) {
        this.onChangeByTagIds(this.form, currentValue);
      }
    }
  }

  onChangeByTagIds = (core, tagIdArr) => {
    // 为了保证顺序渲染，分开赋值
    if (tagIdArr && Array.isArray(tagIdArr) && tagIdArr.length > 0) {
      const [tag1, tag2, tag3, tag4] = tagIdArr;

      if (tag1) {
        core.setValue('tag1', tag1);
      }
      if (tag2) {
        core.setValue('tag2', tag2);
        this.loadTags(tag1, 2);
        if (tag3) {
          core.setValue('tag3', tag3);
          this.loadTags(tag2, 3);
          if (tag4 && Array.isArray(tag4) && tag4.length > 0) {
            core.setValue('tag4', tag4);
            this.loadTagsById(4, tag4);
          }
        }
      }
    }
  }

  // 通过Id和等级查询标签
  loadTagsById = (level, id) => {

    this.props.dispatch({
      type: 'tags/tagsById',
      payload: {
        level,
        id,
      },
      callback: (tags) => {
        const name = level === 1 ? 'tag1' : (level === 2 ? 'tag2' : (level === 3 ? 'tag3' : 'tag4'));
        if (name === 'tag4') {
          const tag4Options = [];
          tags.forEach(i => {
            tag4Options.push(
              <Option key={i.value} value={i.value} label={i.label}>{i.label}</Option>
            )
          })
          this.setState({
            tag4Options,
          })
        } else {
          this.form.setProps(name, { options: tags });
        }
      },
    });
  }

  loadTags = (pId, level, keyword = '') => {
    this.props.dispatch({
      type: 'tags/tagsLevel',
      payload: {
        level,
        pId,
        keyword,
      },
      callback: (tags) => {
        const name = level === 1 ? 'tag1' : (level === 2 ? 'tag2' : (level === 3 ? 'tag3' : 'tag4'));
        if (name === 'tag4') {
          const { options: optionsOrigin = [] } = this.form.getProps(name);
          const tag4Options = [];

          if (Array.isArray(tags) && tags.length <= 0) {
            tag4Options.push(
              <Option key={keyword} value={keyword} label={keyword}><span style={{ color: "red" }}>Add</span> {keyword}</Option>
            )
          } else {
            [...optionsOrigin, ...tags].forEach(i => {
              tag4Options.push(
                <Option key={i.value} value={i.value} label={i.label}>{i.label}</Option>
              )
            })
          }
          this.setState({
            tag4Options,
          })
          // this.form.setProps(name, { options });
        } else {
          this.form.setProps(name, { options: tags });
        }
      },
    })
  }

  // 动态搜索
  showSearch = (value) => {
    if (value && value.length > 0) {
      this.loadTags(0, 4, value);
    }
  }

  render() {
    const { tagsLevel, maxLevel = 4, hasLabel = false } = this.props;
    const { tag4Options } = this.state;

    return (
      <div style={{ width: 200 }}>
        <Form core={this.form} direction='horizontal'>
          <FormItem name='tag1' label={hasLabel ? '一级标签' : null} layout={{ control: 4 }} listenKeys={['tag1']}>
            <Select options={tagsLevel} placeholder="一级标签" />
          </FormItem>
          <If when={(values) => {
            if (values.tag1 && maxLevel >= 2) {
              return true;
            } else {
              return false;
            }
          }
          }
          >
            <FormItem name='tag2' label={hasLabel ? '二级标签' : null} layout={{ control: 4 }} listenKeys={['tag2']}>
              <Select placeholder="二级标签" />
            </FormItem>
          </If>
          <If when={(values) => {
            if (values.tag2 && maxLevel >= 3) {
              return true;
            } else {
              return false;
            }
          }
          }
          >
            <FormItem name='tag3' label={hasLabel ? '三级标签' : null} layout={{ control: 4 }}>
              <Select mode={this.multiple.tag3 ? 'multiple' : ''} placeholder="三级标签" />
            </FormItem>
          </If>
          <If when={(values) => {
            if (values.tag3 && maxLevel >= 4) {
              return true;
            } else {
              return false;
            }
          }
          }
          >
            <FormItem name='tag4' label={hasLabel ? '四级标签' : null} layout={{ control: 4 }}>
              <Select
                onSearch={_.debounce(this.showSearch, 500)}
                placeholder="四级标签"
                mode="multiple"
                optionLabelProp='label'
                optionFilterProp="children"
                filterOption={(input, option) => option.props.children.indexOf(input) >= 0}
              >
                {tag4Options}
              </Select>
            </FormItem>
          </If>
        </Form>
      </div>
    )
  }
}

export default Tags;
