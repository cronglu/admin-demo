import React, { PureComponent } from 'react'
import { message } from 'antd'
import { baseUrl } from 'utils/config';
import Upload from "./UploadCustom";

export default class OssAudio extends PureComponent {

  uploadUrl = `${baseUrl}/admin/sys/upload/audio`;

  beforeUpload = (file) => {
    const isAudio = file.type === 'audio/mp3' || file.type === 'audio/wma' || file.type === 'audio/aac' || file.type === 'audio/wave';
    if (!isAudio) {
      message.error('You can only upload mp3 wma aac wave file!');
      return false;
    }
    const isLt20M = file.size / 1024 / 1024 < 20;
    if (!isLt20M) {
      message.error('Audio must smaller than 20MB!');
      return false;
    }
    return isAudio && isLt20M;
  }

  render() {
    return (
      <Upload {...this.props} beforeUpload={this.beforeUpload} action={this.uploadUrl} listType='text' />
    )
  }
}



