import React, { PureComponent } from 'react'
import { message } from 'antd'
import { baseUrl } from 'utils/config';
import Upload from "./UploadCustom";

export default class OssImage extends PureComponent {

  uploadUrl = `${baseUrl}/admin/sys/upload/picture`;

  beforeUpload = (file) => {
    const isJPG = file.type === 'image/jpeg' || file.type === 'image/png' || file.type === 'image/gif';
    if (!isJPG) {
      message.error('You can only upload JPG PNG GIF file!');
      return false;
    }
    const isLt2M = file.size / 1024 / 1024 < 5;
    if (!isLt2M) {
      message.error('Image must smaller than 5MB!');
      return false;
    }
    return isJPG && isLt2M;
  }

  render() {
    const { beforeUpload = this.beforeUpload } = this.props;
    return (
      <>
        <Upload style={{ width: '100px', float: 'left', marginRight: '8px' }} {...this.props} beforeUpload={beforeUpload} action={this.uploadUrl} />
        {this.props.children}
      </>
    )
  }
}

