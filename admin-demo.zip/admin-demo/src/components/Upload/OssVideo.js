import React, { PureComponent } from 'react'
import { Icon, Modal, Button, Progress, Upload, message } from 'antd';
import { baseUrl } from 'utils/config';
import { findIndex, isEmpty } from 'lodash';


function getBase64(img, callback) {
  const reader = new FileReader();
  reader.addEventListener('load', () => callback(reader.result));
  reader.readAsDataURL(img);
}

function getCurrentFile(fileList = []) {
  const currentFile = fileList.length > 0 ? fileList[fileList.length - 1] : {};
  return currentFile;
}

const uploadUrl = `${baseUrl}/admin/sys/upload/video`;
const API_SUCCESS = 200;

const defaultProps = {
  name: 'file',
  action: uploadUrl,
  defaultFileList: [],
};

export default class OssVideo extends PureComponent {

  constructor(props) {
    super(props);
    this.key = Math.random().toString(36).slice(2);
    this.state = {
      loading: false,
      previewVisible: false,
      previewImage: '',
      percent: 0,
    }
  }

  // 预览
  onPreview = (file) => {
    this.setState({
      previewImage: file.url || file.thumbUrl,
      previewVisible: true,
    });
  }

  onChange = (info) => {
    console.log(info, 'onchange');
    this.setState({
      percent: Math.floor(info.file.percent),
    })
    if (info.file.status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (info.file.status === 'done') {
      console.log(info.file, info.fileList);

      const { value: fileList = [] } = this.props;
      const currentFile = getCurrentFile(fileList);
      const { response } = info.file

      if (!isEmpty(currentFile)) {
        const file = Object.assign(
          currentFile,
          { status: response.errcode === API_SUCCESS ? "done" : "error" },
          { response }
        )
        const fileIndex = findIndex(fileList, { uid: file.uid });

        if (fileIndex >= 0) {
          fileList.splice(fileIndex, 1, file);
        }

        getBase64(file.originFileObj, imageUrl => this.setState({
          previewImage: imageUrl,
          loading: false,
        }));
      }

      const newFileList = [];

      info.fileList.forEach(i => {
        newFileList.push({
          uid: i.uid,
          name: i.name,
          status: i.status,
          url: i.url || i.response.data.url,
        })
      })

      if (this.props.onSuccess) {
        this.props.onSuccess(newFileList);
      }
      message.success(`${info.file.name} 上传成功`);
    } else if (info.file.status === 'removed') {
      if (this.props.onSuccess) {
        this.props.onSuccess([]);
      }
    } else if (info.file.status === 'error') {
      message.error(`${info.file.name} 上传失败.`);
    }
  }

  handleCancel = () => { this.setState({ previewVisible: false }) }

  beforeUpload = (file) => {
    console.log('info beform');

    const isMp4 = file.type === 'video/mp4';
    if (!isMp4) {
      message.error('You can only upload MP4 file!');
      return false;
    }
    const isLt100M = file.size / 1024 / 1024 < 100;
    if (!isLt100M) {
      message.error('Image must smaller than 100MB!');
      return false;
    }
    return isMp4 && isLt100M;
  }

  render() {
    const { previewVisible, previewImage } = this.state;
    const { listLength = 1, value: fileList = [], beforeUpload = () => { }, listType = 'picture' } = this.props;
    const uploadButton = <Button><Icon type={this.state.loading ? 'loading' : 'upload'} /> Upload </Button>
    console.log(fileList, this.props, 'video 组件的属性');
    defaultProps.defaultFileList = fileList;
    console.log(defaultProps, 'props');

    return (
      <div>
        <Upload
          onChange={this.onChange}
          {...defaultProps}
          listType={listType}
          beforeUpload={beforeUpload}
          style={{ margin: 0 }}
        >
          {fileList && fileList.length >= listLength ? null : uploadButton}
        </Upload>
        <Modal visible={previewVisible} footer={null} onCancel={this.handleCancel}>
          <video alt="查看大图" style={{ width: '100%' }} src={previewImage} controls="controls">good luck</video>
        </Modal>
        {fileList && fileList.length >= listLength ? null : <Progress percent={this.state.percent} />}
      </div>
    )
  }
}