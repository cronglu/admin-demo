import React, { PureComponent } from 'react'
import { Icon, Modal, Button, Progress } from 'antd';
import { Upload } from 'nowrapper/lib/antd';
import { baseUrl } from 'utils/config';
import { findIndex, isEmpty } from 'lodash';


function getBase64(img, callback) {
  const reader = new FileReader();
  reader.addEventListener('load', () => callback(reader.result));
  reader.readAsDataURL(img);
}

function getCurrentFile(fileList = []) {
  const currentFile = fileList.length > 0 ? fileList[fileList.length - 1] : {};
  return currentFile;
}

const uploadUrl = `${baseUrl}/admin/sys/upload/file`;
const API_SUCCESS = 200;

class UploadCustom extends PureComponent {

  defaultFileUploadProps = {
    onSuccess: (response) => {
      const { value: fileList = [] } = this.props;
      const currentFile = getCurrentFile(fileList);

      if (!isEmpty(currentFile)) {
        const file = Object.assign(
          currentFile,
          { status: response.errcode === API_SUCCESS ? "done" : "error" },
          { response }
        )
        const fileIndex = findIndex(fileList, { uid: file.uid });

        if (fileIndex >= 0) {
          fileList.splice(fileIndex, 1, file);
        }

        getBase64(file.originFileObj, imageUrl => this.setState({
          previewImage: imageUrl,
          loading: false,
        }));
      }

      const newFileList = [];

      fileList.forEach(i => {
        newFileList.push({
          uid: i.uid,
          name: i.name,
          status: i.status,
          url: i.url || i.response.data.url,
        })
      })

      if (this.props.onSuccess) {
        this.props.onSuccess(newFileList);
      }
    },

    // 预览
    onPreview: (file) => {
      this.setState({
        previewImage: file.url || file.thumbUrl,
        previewVisible: true,
      });
    },
  };

  constructor(props) {
    super(props);
    this.key = Math.random().toString(36).slice(2);
    this.state = {
      loading: false,
      previewVisible: false,
      previewImage: '',
    }
  }

  onRemove = (file) => {
    console.log(file, 'remove');
    // TODO 从OSS 上删掉
  }

  handleCancel = () => { this.setState({ previewVisible: false }) }

  onChange = (e) => {
    console.log(e.event, 'asadfasgsa')
  }

  render() {
    // console.log(this.props, 'props');

    const { previewVisible, previewImage } = this.state;
    const { listLength = 1, value: fileList = [], beforeUpload = () => { }, listType = 'picture', action = { uploadUrl } } = this.props;
    const uploadButton = <Button><Icon type={this.state.loading ? 'loading' : 'upload'} /> Upload </Button>

    return (
      <div>
        <Upload
          onChange={this.onChange}
          {...this.props}
          listType={listType}
          {...this.defaultFileUploadProps}
          beforeUpload={beforeUpload}
          action={action}
          style={{ margin: 0 }}
        >
          {fileList && fileList.length >= listLength ? null : uploadButton}
        </Upload>
        <Modal visible={previewVisible} footer={null} onCancel={this.handleCancel}>
          <img alt="查看大图" style={{ width: '100%' }} src={previewImage} />
        </Modal>
      </div>
    )
  }
}

export default UploadCustom;
