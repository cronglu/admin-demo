import React, { PureComponent } from 'react';
import { Popover, Icon } from 'antd';
import { envMap } from 'utils/config';
import styles from './index.less';

export default class SwitchEnv extends PureComponent {
  state = {
    visible: false,
  };

  onVisible = () => {
    this.setState(preState => ({
      visible: !preState.visible,
    }));
  };

  onSelect = env => {
    const { key, url } = env;
    localStorage.env = key;
    localStorage.url = url;
    window.location.href = '/login';
  };

  render() {
    const { visible } = this.state;
    const { env = 'staging' } = localStorage;
    return (
      <div className={styles.container}>
        <Popover
          placement="topRight"
          align={{
            overflow: { adjustY: 0, adjustX: 0 },
            offset: [-3, -10],
          }}
          visible={visible}
          content={
            <>
              {envMap.map(i => (
                <div
                  key={i.key}
                  className={i.key === env ? styles.selected : styles.item}
                  onClick={() => this.onSelect(i)}
                >
                  {i.name}
                </div>
              ))}
            </>
          }
        >
          <Icon
            type="code"
            style={{ color: '#1890ff', fontSize: '50px' }}
            onClick={this.onVisible}
          />
        </Popover>
      </div>
    );
  }
}
