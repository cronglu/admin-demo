import React from 'react';
import withRouter from 'umi/withRouter';
import { LocaleProvider } from 'antd';
import zhCN from 'antd/lib/locale-provider/zh_CN';
import 'moment/locale/zh-cn';
import { isProd } from 'utils/config';
import SwithEnv from '../components/SwitchEnv';
import BasicLayout from './BasicLayout';
import LoginLayout from './LoginLayout';

export default withRouter(props => {
  return (
    <LocaleProvider locale={zhCN}>
      <>
        {props.location.pathname !== '/login' ? (
          <BasicLayout {...props}>{props.children}</BasicLayout>
        ) : (
          <LoginLayout>{props.children}</LoginLayout>
        )}
        {!isProd && <SwithEnv />}
      </>
    </LocaleProvider>
  );
});
