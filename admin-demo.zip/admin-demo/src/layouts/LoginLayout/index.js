import React from 'react';
import GlobalFooter from 'components/GlobalFooter';
import styles from './index.less';

export default ({ children }) => (
  <div className={styles.container}>
    <div className={styles.content}>
      <div className={styles.top}>
        <div className={styles.header}>
          <span className={styles.title}>金牌宠物</span>
        </div>
        <div className={styles.desc}>爱生活、爱宠物</div>
      </div>
      {children}
    </div>
    <GlobalFooter />
  </div>
);
