import React, { PureComponent } from 'react';
import { connect } from 'dva';
import Redirect from 'umi/redirect';
import classNames from 'classnames';
import { enquireScreen } from 'enquire-js';
import { ContainerQuery } from 'react-container-query';
import { Layout, Row, Col } from 'antd';
import { Form, FormCore, FormItem, Input, DialogForm } from 'antd-noform';
import { Countdown } from 'components';
import Exception from 'ant-design-pro/lib/Exception';
import GlobalHeader from 'components/GlobalHeader';
import GlobalFooter from 'components/GlobalFooter';
import SliderMenu from 'components/SliderMenu';
import Authorized from 'components/Authorized';
import isEqual from 'lodash/isEqual';
import memoizeOne from 'memoize-one';
import Context from "components/Utils/MenuContext";
import { getVerifyCode } from "../../services";
// import logo from '../../assets/logo.png';

const { Content, Header, Footer } = Layout;

// Conversion router to menu.
function formatter(data, authority) {
  return data
    .map(item => {
      if (!item.name || !item.path) {
        return null;
      }

      const result = {
        ...item,
        authority: authority[item.path] || {},
      };
      delete result.routes;
      return result;
    })
    .filter(item => item);
}

const memoizeOneFormatter = memoizeOne(formatter, isEqual);
const query = {
  'screen-xs': {
    maxWidth: 575,
  },
  'screen-sm': {
    minWidth: 576,
    maxWidth: 767,
  },
  'screen-md': {
    minWidth: 768,
    maxWidth: 991,
  },
  'screen-lg': {
    minWidth: 992,
    maxWidth: 1199,
  },
  'screen-xl': {
    minWidth: 1200,
  },
};

// eslint-disable-next-line
let isMobile;
enquireScreen(b => {
  isMobile = b;
});

@connect(({ global }) => global)
class BasicLayout extends PureComponent {
  constructor(props) {
    super(props);

    this.getBreadcrumbNameMap = memoizeOne(this.getBreadcrumbNameMap, isEqual);
    this.breadcrumbNameMap = this.getBreadcrumbNameMap();
    console.log(this.breadcrumbNameMap, 'breadMap router');

    this.form = new FormCore({
      validateConfig: {
        verifyCode: [{ required: true, message: '请输入验证码' }],
        newLecturerParssword: [{ required: true, message: '请输入新密码' }],
      },
    });
  }

  state = {
    isMobile: false,
  };

  componentDidMount() {
    enquireScreen(mobile => {
      this.setState({
        isMobile: mobile,
      });
    });
  }

  componentDidUpdate(preProps) {
    // After changing to phone mode,
    // if collapsed is true, you need to click twice to display
    this.breadcrumbNameMap = this.getBreadcrumbNameMap();
    const { collapsed } = this.props;
    if (isMobile && !preProps.isMobile && !collapsed) {
      this.handleMenuCollapse(false);
    }
  }

  getContext() {
    const { location } = this.props;
    return {
      location,
      breadcrumbNameMap: this.breadcrumbNameMap,
    };
  }

  getMenuData() {
    const { menu, authority } = this.props;
    return memoizeOneFormatter(menu, authority);
  }

  /**
   * 获取面包屑映射
   * @param {Object} menuData 菜单配置
   */
  getBreadcrumbNameMap() {

    const routerMap = {};
    const mergeMenuAndRouter = data => {
      data.forEach(menuItem => {
        if (menuItem.children) {
          mergeMenuAndRouter(menuItem.children);
        }
        // Reduce memory usage
        routerMap[menuItem.path] = menuItem;
      });
    };
    mergeMenuAndRouter(this.getMenuData());
    return routerMap;
  }

  handleMenuCollapse = collapsed => {
    this.props.dispatch({
      type: 'global/changeLayoutCollapsed',
      payload: collapsed,
    });
  };

  handleMenuClick = ({ key }) => {
    if (key === 'logout') {
      this.props.dispatch({
        type: 'global/logout',
      });
    } else if (key === 'changePassword') {
      this.onChangePassword();
    }
  };

  onChangePassword = () => {
    const {
      adminInfo: { mobile, countryCode = 86 },
    } = this.props;

    const onOk = (values, hide) => {
      this.form.validate(errors => {
        if (!errors) {
          this.props.dispatch({
            type: 'global/changePassword',
            payload: values,
            callback: () => {
              hide();
              this.props.dispatch({
                type: 'global/logout',
              });
            },
          });
        }
      });
    };

    const onClickSending = async () => {
      const hasError = await this.form.validateItem('mobile');
      const flag = !hasError;
      if (flag) {
        await getVerifyCode({ countryCode, mobile });
      }
      return flag;
    };

    this.form.setValues({
      mobile,
      countryCode,
      verifyCode: '',
      newLecturerParssword: '',
    });

    DialogForm.show({
      title: '修改密码',
      width: 600,
      onOk,
      content: (
        <Form core={this.form}>
          <Row style={{ marginTop: '12px', marginBottom: '12px' }}>
            <Col span={5}>
              <FormItem name="countryCode" label="区号" status="disabled" defaultMinWidth={false}>
                <Input style={{ width: 50 }} />
              </FormItem>
            </Col>
            <Col span={9}>
              <FormItem
                name="mobile"
                label="手机号"
                status="disabled"
                defaultMinWidth={false}
              >
                <Input style={{ width: 120 }} />
              </FormItem>
            </Col>
            <Col span={7}>
              <FormItem><Countdown onClickSending={onClickSending} /></FormItem>
            </Col>
          </Row>
          <FormItem name="verifyCode" label="验证码">
            <Input placeholder="请输入" />
          </FormItem>
          <FormItem name="newLecturerParssword" label="新密码">
            <Input placeholder="请输入" />
          </FormItem>
        </Form>
      ),
    });
  };



  render() {
    const {
      adminInfo: { nickname: name },
      collapsed,
      location,
      menu,
      login,
    } = this.props;
    const currentUser = {
      name,
      avatar: 'https://gw.alipayobjects.com/zos/rmsportal/BiazfanxmamNRoxxVxka.png',
    };

    const layout = (
      <Layout>
        <SliderMenu
          {...this.props}
          // logo={logo}
          menuData={menu}
          collapsed={collapsed}
          location={location}
          isMobile={this.state.isMobile}
          onCollapse={this.handleMenuCollapse}
        />
        <Layout>
          <Header style={{ padding: 0 }}>
            <GlobalHeader
              // logo={logo}
              currentUser={currentUser}
              collapsed={collapsed}
              isMobile={this.state.isMobile}
              onCollapse={this.handleMenuCollapse}
              onMenuClick={this.handleMenuClick}
            />
          </Header>
          <Content style={{ margin: '24px 24px 0', height: '100%' }}>
            <Authorized noMatch={<Exception type="403" />}>{this.props.children}</Authorized>
          </Content>
          <Footer style={{ padding: 0 }}>
            <GlobalFooter />
          </Footer>
        </Layout>
      </Layout>
    );

    return login ? (
      <ContainerQuery query={query}>
        {params => (
          <Context.Provider value={this.getContext()}>
            <div className={classNames(params)}>{layout}</div>
          </Context.Provider>
        )}
      </ContainerQuery>
    ) : (
      <Redirect to="/login" />
      );
  }
}

export default BasicLayout;
