import React, { PureComponent } from 'react';
// import PageHeader from 'ant-design-pro/lib/PageHeader';
import Link from 'umi/link';
import { Icon, PageHeader } from 'antd';
import MenuContext from 'components/Utils/MenuContext';
import styles from './index.less';

export default class PageHeaderLayout extends PureComponent {

  render() {
    const {
      title,
      children,
      wrapperClassName,
      extra,
      subTitle,
      style = {},
      hideInBread,
    } = this.props;
    const defaultStyle = { margin: '-24px -24px 0' }

    const itemRender = (route, params, routes, paths) => {
      const last = routes.indexOf(route) === routes.length - 1;

      return last ? (
        <span>{route.breadcrumbName}</span>
      ) : (
        <Link to={route.path} style={{ color: '#0000ff' }}>{route.breadcrumbName}</Link>
        );
    }

    return (
      <div>
        <div
          style={{ ...defaultStyle, ...style }}
          className={wrapperClassName}
        >
          {title && (
            <MenuContext.Consumer>
              {
                // 临时处理routes 配置
                value => {

                  const { breadcrumbNameMap, location } = value;
                  const routes = [];
                  let tmpPath = '';

                  const arr = location.pathname.split('/');

                  arr.forEach((item, index) => {
                    if (item === '') {
                      routes.push({
                        'path': '/',
                        breadcrumbName: <Icon type="home" />,
                      })
                    } else {
                      tmpPath = arr.slice(0, index + 1).join('/');

                      if (!breadcrumbNameMap[tmpPath].children || breadcrumbNameMap[tmpPath].component) {
                        routes.push({
                          path: tmpPath,
                          breadcrumbName: breadcrumbNameMap[tmpPath].name,
                        })
                      }
                    }
                  })

                  return (
                    <PageHeader
                      style={{ background: "rgba(255, 255, 255, 0.9)" }}
                      extra={extra}
                      title={<span style={{ fontSize: 16 }}>{title}</span>}
                      subTitle={subTitle}
                      key="pageheader"
                      home={<Icon type="home" />}
                      breadcrumb={hideInBread && { routes, itemRender }}
                      location={value.location}
                      linkElement={Link}
                    />
                  )
                }
              }
            </MenuContext.Consumer>
          )}
          {children ? <div className={styles.content}>{children}</div> : null}
        </div>
      </div>
    )
  }
}
