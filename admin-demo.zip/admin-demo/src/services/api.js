import request from 'utils/request';

// 菜单列表
export async function authList() {
  return request(`/admin/auth/all`, {});
}

// 获取菜单树
export async function authTree() {
  return request(`/admin/auth/get_tree_list`, {});
}

// 保存菜单排序
export async function saveAuthTree(payload = {}) {
  return request(`/admin/auth/save_tree_list`, payload);
}

// 角色列表
export async function roleList() {
  return request(`/admin/role/all`, {});
}

// 获取用户列表
export async function getUserList() {
  return request('/admin/user/users', {});
}

// 标签联动查询
export async function tagsCondition(payload = {}) {
  return request('/admin/tags/condition', payload);
}

// 通过id和level查询标签
export async function tagsByIds(params) {
  return request('/admin/tags/id', params);
}

export async function getAllTags() {
  return request('/admin/tags/all', {});
}

export async function petKinds(payload = {}) {
  return request('/admin/pet/kinds', payload);
}

export async function region(payload = {}) {
  return request('/admin/region/all', payload);
}

export async function usersVirtual(payload = {}) {
  return request('/admin/user/virtual/all', payload);
}















