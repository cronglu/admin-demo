import request from 'utils/request';

export async function getVerifyCode(body) {
  return request(`/xxx/getVerifyCode`, {
    method: 'POST',
    body,
  });
}

export async function getMenuData() {
  return request(`/admin/menu`, {
    method: 'get',
  });
}
