import router from 'umi/router';
import { loginApi } from '../pages/login/services';
import { getMenuData } from '../services/index';

const loginInfo = sessionStorage.loginInfo ? JSON.parse(sessionStorage.loginInfo) : {};

export default {
	namespace: 'global',

	state: {
		login: false,
		collapsed: false,
		adminInfo: {
			realName: 'admin',
		},
		menu: [],
		authority: {},
		currentUser: {
			name: '',
			avatar: 'https://gw.alipayobjects.com/zos/rmsportal/BiazfanxmamNRoxxVxka.png',
		},
		...loginInfo,
	},

	effects: {
		*login({ payload, callback }, { call, put }) {
			try {
				const { nick: nickname, id: userId, menu = [], authority = {}, token = "" } = yield call(
					loginApi,
					payload
				);

				const info = {
					login: true,
					adminInfo: { nickname, userId }, // 登录后返回的用户信息
					menu: [...menu],
					authority: { ...authority },
				};

				sessionStorage.loginInfo = JSON.stringify(info);
				sessionStorage.token = token;
				yield put({
					type: 'changeLoginStatus',
					payload: info,
				});

				router.replace('/');
			} catch (error) {
				console.log(error);
			}
		},
		*logout(_, { put }) {
			sessionStorage.clear();
			yield put({
				type: 'changeLoginStatus',
				payload: {
					login: false,
				},
			});
			router.replace('/login');
		},

		*getMenu(_, { call, put }) {
			const { menu, authority } = yield call(getMenuData, {});

			yield put({
				type: 'save',
				payload: {
					menu,
					authority: {
						...authority,
						'/': {}, // 首页权限
					},
				},
			});
		},
	},

	reducers: {
		changeLayoutCollapsed(state, { payload }) {
			return {
				...state,
				collapsed: payload,
			};
		},

		changeLoginStatus(state, { payload }) {
			const { login, adminInfo = {}, menu = [], authority = {} } = payload;
			return {
				...state,
				login,
				adminInfo,
				menu,
				authority,
			};
		},
		save(state, action) {
			return { ...state, ...action.payload };
		},
	},
};
