import { message } from 'antd';
import { stringify } from 'qs';
import request from 'utils/request';
import { filterObject } from 'utils/utils';

const initState = {
  api: '',
  list: [],
  pagination: {
    current: 1,
    pageSize: 10,
  },
};

export default {
  namespace: 'page',

  state: initState,

  effects: {
    *init({ payload }, { put, select }) {
      let res = {};
      if (typeof payload === 'string') {
        res.api = payload;
      } else {
        const { noPage, ...temRes } = payload;
        res = temRes;
        console.log(res, payload, "init");

      }

      const location = yield select(state => state.routing.location);
      const {
        state: { pagination = { current: 1, pageSize: 10 }, filters = {} },
      } = location.state ? location : { state: {} };
      yield put({
        type: 'save',
        payload: {
          pagination,
          filters,
          ...res,
        },
      });

      yield put({
        type: 'read',
        payload,
      });
    },

    *read({ payload }, { call, put, select }) {
      const { api } = yield select(state => state.page);
      const { pagination, filters } =
        payload && payload.pagination ? payload : yield select(state => state.page);

      const res = yield call(request, payload && payload.noPage ? `${api}` : `${api}/page`, {
        params: {
          ...pagination,
          ...filters,
        },
        noPage: payload && payload.noPage,
      });
      const { api: nowApi } = yield select(state => state.page);
      if (nowApi === api) {
        console.log(res);
        yield put({
          type: 'save',
          payload: { ...res, filters },
        });
      }
    },

    *create({ payload, callback }, { call, put, select }) {
      const { api } = yield select(state => state.page);

      const res = yield call(request, api, {
        method: 'POST',
        body: filterObject(payload),
      });

      yield put({
        type: 'read',
      });

      if (callback) callback(res);
      message.success('创建成功');
    },

    *update({ payload, callback }, { call, put, select }) {
      const { api } = yield select(state => state.page);
      const { id } = payload;

      yield call(request, `${api}/${id}`, {
        method: 'PUT',
        // body: filterObject(payload),
        body: payload, // 修改为空的需求
      });
      yield put({
        type: 'read',
      });
      if (callback) callback();
      message.success('更新成功');
    },

    *delete({ payload: id, callback }, { call, put, select }) {
      const { api } = yield select(state => state.page);
      yield call(request, `${api}/${id}`, {
        method: 'DELETE',
      });
      yield put({
        type: 'read',
      });
      if (callback) callback();
      message.success('删除成功');
    },

    *detail({ payload }, { call, put, select }) {
      const { api } = yield select(state => state.page);
      const { pagination, filters } =
        payload && payload.pagination ? payload : yield select(state => state.page);
      const res = yield call(
        request,
        payload && payload.noPage
          ? `${api}?${stringify(pagination)}`
          : `${api}/page?${stringify(pagination)}`,
        {
          method: 'POST',
          body: filters,
        }
      );

      yield put({
        type: 'save',
        payload: res,
      });
    },

    *close({ payload, callback }, { call, put, select }) {
      const { api } = yield select(state => state.page);
      yield call(request, `${api}/close`, {
        method: 'PUT',
        params: { ...payload },
      });
      yield put({
        type: 'readList',
      });
      if (callback) callback();
      message.success('关闭成功');
    },

    *export(_, { call, select }) {
      const { api, defaultFilters, filters } = yield select(state => state.page);
      const res = yield call(request, `${api}/all`, {
        method: 'POST',
        body: { ...defaultFilters, ...filters },
      });
      if (res) {
        return res;
      }
    },
  },

  reducers: {
    save(state, { payload }) {
      return {
        ...state,
        ...payload,
      };
    },
  },
};
