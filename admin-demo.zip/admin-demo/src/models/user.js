import { usersByName as userSearch, usersVirtual as getVirtual } from '../services/api';

export default {
  namespace: 'users',
  state: {
    usersVirtual: [],
  },

  effects: {
    *usersByName({ payload, callback }, { call }) {
      const { items: userList } = yield call(userSearch, payload)

      if (callback && typeof callback === 'function') {
        callback(userList)
      }
    },

    *usersVirtual({ payload, callback }, { call, put }) {
      const { items: usersVirtual } = yield call(getVirtual, payload)

      if (callback && typeof callback === 'function') {
        callback(usersVirtual)
      }

      yield put({
        type: 'save',
        payload: {
          usersVirtual,
        },
      })
    },
  },

  reducers: {

    save(state, action) {
      return { ...state, ...action.payload };
    },
  },
};
