import React from 'react';

const str = (`<p class="ruleListTable"> ^_^ </p>`
);

export default class extends React.Component {
  componentDidMount () {
    document.querySelector('.test').innerHTML = str;
  }

  render() {
    return (
      <div>
        <div
          className="test"
        />
        {/* <p className="ruleListTable"></p> */}
      </div>
    )
  }
};
