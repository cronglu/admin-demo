import { message } from 'antd';
import request from '../../../utils/request';

export default {
  namespace: 'userList',

  state: {
    userList: [],
  },

  effects: {
    // 封号
    *forbid({ payload, callback }, { call, put }) {
      const response = yield call(request, `/admin/user/forbid`, {
        method: 'DELETE',
        params: payload,
      });
      const msg = payload.status === 1 ? '解封成功' : '封号成功';
      yield put({
        type: 'page/read',
      });

      message.success(msg);
      if (callback && typeof callback === 'function') {
        callback(response);
      }
    },
  },

  reducers: {
    save(state, { payload }) {
      return {
        ...state,
        ...payload,
      };
    },
  },
};
