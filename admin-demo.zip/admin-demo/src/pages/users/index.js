import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Divider, Popconfirm, Avatar, Icon, Tag, Switch } from 'antd';
import { FormItem, Input } from 'antd-noform';
import { Link } from 'react-router-dom';
import { PageTable } from 'components';
import moment from 'moment';

@connect(({ userList }) => ({ ...userList }))
class Page extends PureComponent {
    columns = [
        {
            title: 'ID',
            dataIndex: 'user_center_id',
            align: 'center',
        },
        {
            title: '头像',
            align: 'center',
            render: (item) => <Avatar src={item.icon_url} />,
        },
        {
            title: '昵称',
            dataIndex: 'nick',
            align: 'center',
        },
        {
            title: '性别',
            align: 'center',
            render: (item) => item.gender === 1 ? <Icon type="man" /> : item.gender === 2 ? <Icon type="woman" /> : <Icon type="question" />,
        },
        {
            title: '手机号',
            dataIndex: 'mobile',
            align: 'center',
        },
        {
            title: '状态',
            render: item => <Tag color={item.status === 9 ? "red" : "green"}>{item.status_name}</Tag>,
            align: 'center',
        },
        {
            title: '注册时间',
            render: item => <span>{moment.unix(item.reg_time).format('YYYY-MM-DD HH:mm:ss')}</span>,
            align: 'center',
        },
        {
            title: '封号',
            render: item => (
                <Popconfirm title={item.status === 1 ? '是否封停' : '是否解封'} onConfirm={() => this.onDelete(item)}>
                    <Switch checkedChildren="解封" unCheckedChildren="封停" disabled checked={item.status === 9} />
                </Popconfirm>
            ),
            align: 'center',
        },
        {
            title: '操作',
            align: 'center',
            width: 200,
            render: (item) => (
                <>
                    <Link
                      to={{
                            pathname: '/users/pets',
                            query: { user_id: item.user_center_id },
                            state: { title: item.name },
                        }}
                    >
                        宠物资料
                    </Link>
                    <Divider type='vertical' />

                </>
            ),
        },
    ];


    componentDidMount() {
        const {
            dispatch,
        } = this.props;

        dispatch({
            type: 'page/init',
            payload: '/admin/user/front',
        })
    }

    onDelete = (item) => {
        this.props.dispatch({
            type: 'userList/forbid',
            payload: { "user_id": item.user_center_id, "status": item.status === 1 ? 9 : 1 },
        });
    };

    render() {
        return (
            <PageTable
              title="用户列表"
              columns={this.columns}
              form={
                    <>
                        <FormItem label='关键字' name='keyword'>
                            <Input placeholder='请输入关键字' />
                        </FormItem>
                    </>
                }
            />
        );
    }
}

export default Page;
