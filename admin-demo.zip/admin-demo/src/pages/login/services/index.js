import request from 'utils/request';

export async function loginApi(params) {
	return request(`/admin/login`, {
		method: 'GET',
		params,
	});
}
