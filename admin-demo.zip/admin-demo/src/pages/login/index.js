import React, { PureComponent } from 'react';
import { connect } from 'dva';
import Login from 'ant-design-pro/lib/Login';
import { message } from 'antd';
import { Form, FormCore } from 'antd-noform';

const { UserName, Password, Submit } = Login;

@connect()
class LoginPage extends PureComponent {
    constructor() {
        super();
        this.form = new FormCore({
            validateConfig: {
                countryCode: [{ required: true, message: '请输入区号' }],
                mobile: [
                    { required: true, message: '请输入手机号码' },
                    {
                        pattern: /^((1[3-8][0-9])+\d{8})$/,
                        message: '请输入正确的手机号码',
                    },
                ],
                verifyCode: [{ required: true, message: '请输入验证码', trigger: 'onBlur' }],
                newLecturerParssword: [{ required: true, message: '请输入新密码' }],
            },
        });
    }

    onSubmit = (err, values) => {
        if (!err) {
            console.log(values, 'values');

            this.props.dispatch({
                type: 'global/login',
                payload: values,
                callback: (res) => {
                    if (!res.status) {
                        message.error(res.errMsg);
                    }
                },
            });
        }

    };

    render() {
        return (
          <div style={{ maxWidth: '368px', margin: 'auto' }}>
              <Login onTabChange={this.onTabChange} onSubmit={this.onSubmit}>
                  <UserName
                      name="username"
                      placeholder="请输入用户名"
                      rules={[{ required: true, message: '请输入用户名' }]}
                    />
                  <Password
                      name="password"
                      placeholder="请输入密码"
                      rules={[{ required: true, message: '请输入密码' }]}
                    />
                  <Submit onSubmit={this.onSubmit}>登录</Submit>
                </Login>
            </div>
        );
    }
}

export default LoginPage;
