import dva from 'dva';
import { Component } from 'react';
import createLoading from 'dva-loading';
import history from '@tmp/history';

let app = null;

export function _onCreate() {
  const plugins = require('umi/_runtimePlugin');
  const runtimeDva = plugins.mergeConfig('dva');
  app = dva({
    history,
    ...((require('/Library/PHP/www/pet-admin/src/dva.js').config || (() => ({})))()),
    ...(runtimeDva.config || {}),
    ...(window.g_useSSR ? { initialState: window.g_initialData } : {}),
  });
  
  app.use(createLoading());
  (runtimeDva.plugins || []).forEach(plugin => {
    app.use(plugin);
  });
  
  app.model({ namespace: 'chart', ...(require('/Library/PHP/www/pet-admin/src/models/chart.js').default) });
app.model({ namespace: 'global', ...(require('/Library/PHP/www/pet-admin/src/models/global.js').default) });
app.model({ namespace: 'order', ...(require('/Library/PHP/www/pet-admin/src/models/order.js').default) });
app.model({ namespace: 'page', ...(require('/Library/PHP/www/pet-admin/src/models/page.js').default) });
app.model({ namespace: 'res', ...(require('/Library/PHP/www/pet-admin/src/models/res.js').default) });
app.model({ namespace: 'tags', ...(require('/Library/PHP/www/pet-admin/src/models/tags.js').default) });
app.model({ namespace: 'user', ...(require('/Library/PHP/www/pet-admin/src/models/user.js').default) });
  return app;
}

export function getApp() {
  return app;
}

export class _DvaContainer extends Component {
  render() {
    const app = getApp();
    app.router(() => this.props.children);
    return app.start()();
  }
}
