import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@tmp/history';
import RendererWrapper0 from '/Library/PHP/www/pet-admin/src/pages/.umi/LocaleWrapper.jsx';
import _dvaDynamic from 'dva/dynamic';

const Router = require('dva/router').routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () => import('../../layouts/index.js'),
        })
      : require('../../layouts/index.js').default,
    routes: [
      {
        path: '/404',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../404.js'),
            })
          : require('../404.js').default,
      },
      {
        path: '/admin/admin-list',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import('/Library/PHP/www/pet-admin/src/pages/admin/models/admin.js').then(
                  m => {
                    return { namespace: 'admin', ...m.default };
                  },
                ),
              ],
              component: () => import('../admin/admin-list.js'),
            })
          : require('../admin/admin-list.js').default,
      },
      {
        path: '/admin/auth-list',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import('/Library/PHP/www/pet-admin/src/pages/admin/models/admin.js').then(
                  m => {
                    return { namespace: 'admin', ...m.default };
                  },
                ),
              ],
              component: () => import('../admin/auth-list.js'),
            })
          : require('../admin/auth-list.js').default,
      },
      {
        path: '/admin/official',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import('/Library/PHP/www/pet-admin/src/pages/admin/models/admin.js').then(
                  m => {
                    return { namespace: 'admin', ...m.default };
                  },
                ),
              ],
              component: () => import('../admin/official.js'),
            })
          : require('../admin/official.js').default,
      },
      {
        path: '/admin/role-list',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import('/Library/PHP/www/pet-admin/src/pages/admin/models/admin.js').then(
                  m => {
                    return { namespace: 'admin', ...m.default };
                  },
                ),
              ],
              component: () => import('../admin/role-list.js'),
            })
          : require('../admin/role-list.js').default,
      },
      {
        path: '/admin/test-user',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import('/Library/PHP/www/pet-admin/src/pages/admin/models/admin.js').then(
                  m => {
                    return { namespace: 'admin', ...m.default };
                  },
                ),
              ],
              component: () => import('../admin/test-user.js'),
            })
          : require('../admin/test-user.js').default,
      },
      {
        path: '/adopt/adopt-list',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../adopt/adopt-list.js'),
            })
          : require('../adopt/adopt-list.js').default,
      },
      {
        path: '/adopt/position',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../adopt/position.js'),
            })
          : require('../adopt/position.js').default,
      },
      {
        path: '/adopt/report',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../adopt/report.js'),
            })
          : require('../adopt/report.js').default,
      },
      {
        path: '/banner',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../banner/index.js'),
            })
          : require('../banner/index.js').default,
      },
      {
        path: '/',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../index.js'),
            })
          : require('../index.js').default,
      },
      {
        path: '/login',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../login/index.js'),
            })
          : require('../login/index.js').default,
      },
      {
        path: '/material/article',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../material/article.js'),
            })
          : require('../material/article.js').default,
      },
      {
        path: '/material/tags',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../material/tags.js'),
            })
          : require('../material/tags.js').default,
      },
      {
        path: '/material/video',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../material/video.js'),
            })
          : require('../material/video.js').default,
      },
      {
        path: '/orders/comment',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../orders/comment.js'),
            })
          : require('../orders/comment.js').default,
      },
      {
        path: '/orders/goods',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../orders/goods.js'),
            })
          : require('../orders/goods.js').default,
      },
      {
        path: '/orders/order-list',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () => import('../orders/order-list.js'),
            })
          : require('../orders/order-list.js').default,
      },
      {
        path: '/treatment/doctor-treat/reply',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import('/Library/PHP/www/pet-admin/src/pages/treatment/models/treat.js').then(
                  m => {
                    return { namespace: 'treat', ...m.default };
                  },
                ),
              ],
              component: () => import('../treatment/doctor-treat/reply.js'),
            })
          : require('../treatment/doctor-treat/reply.js').default,
      },
      {
        path: '/treatment/doctor-treat',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import('/Library/PHP/www/pet-admin/src/pages/treatment/models/treat.js').then(
                  m => {
                    return { namespace: 'treat', ...m.default };
                  },
                ),
              ],
              component: () => import('../treatment/doctor-treat.js'),
            })
          : require('../treatment/doctor-treat.js').default,
      },
      {
        path: '/treatment/treat-info',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import('/Library/PHP/www/pet-admin/src/pages/treatment/models/treat.js').then(
                  m => {
                    return { namespace: 'treat', ...m.default };
                  },
                ),
              ],
              component: () => import('../treatment/treat-info.js'),
            })
          : require('../treatment/treat-info.js').default,
      },
      {
        path: '/users',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import('/Library/PHP/www/pet-admin/src/pages/users/models/userList.js').then(
                  m => {
                    return { namespace: 'userList', ...m.default };
                  },
                ),
              ],
              component: () => import('../users/index.js'),
            })
          : require('../users/index.js').default,
      },
      {
        path: '/users/pets',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import('/Library/PHP/www/pet-admin/src/pages/users/models/userList.js').then(
                  m => {
                    return { namespace: 'userList', ...m.default };
                  },
                ),
              ],
              component: () => import('../users/pets.js'),
            })
          : require('../users/pets.js').default,
      },
      {
        path: '/users/virtual',
        exact: true,
        component: __IS_BROWSER
          ? _dvaDynamic({
              app: require('@tmp/dva').getApp(),
              models: () => [
                import('/Library/PHP/www/pet-admin/src/pages/users/models/userList.js').then(
                  m => {
                    return { namespace: 'userList', ...m.default };
                  },
                ),
              ],
              component: () => import('../users/virtual.js'),
            })
          : require('../users/virtual.js').default,
      },
      {
        component: () =>
          React.createElement(
            require('/Library/PHP/www/pet-admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: false },
          ),
      },
    ],
  },
  {
    component: () =>
      React.createElement(
        require('/Library/PHP/www/pet-admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: false },
      ),
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen = () => {};

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    routeChangeHandler(history.location);
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper0>
        <Router history={history}>{renderRoutes(routes, props)}</Router>
      </RendererWrapper0>
    );
  }
}
