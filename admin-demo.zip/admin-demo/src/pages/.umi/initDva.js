import dva from 'dva';
import createLoading from 'dva-loading';

const runtimeDva = window.g_plugins.mergeConfig('dva');
let app = dva({
  history: window.g_history,
  ...((require('/Library/PHP/www/new-admin/src/dva.js').config || (() => ({})))()),
  ...(runtimeDva.config || {}),
});

window.g_app = app;
app.use(createLoading());
(runtimeDva.plugins || []).forEach(plugin => {
  app.use(plugin);
});

app.model({ namespace: 'chart', ...(require('/Library/PHP/www/new-admin/src/models/chart.js').default) });
app.model({ namespace: 'global', ...(require('/Library/PHP/www/new-admin/src/models/global.js').default) });
app.model({ namespace: 'page', ...(require('/Library/PHP/www/new-admin/src/models/page.js').default) });
app.model({ namespace: 'tags', ...(require('/Library/PHP/www/new-admin/src/models/tags.js').default) });
app.model({ namespace: 'user', ...(require('/Library/PHP/www/new-admin/src/models/user.js').default) });
