import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Divider, Popconfirm } from 'antd';
import { Form, FormCore, FormItem, Input, DialogForm, Select } from 'antd-noform';
import { PageTable } from 'components';
import moment from 'moment';

const defaultValues = {
  id: undefined,
  account: undefined,
  passwd: undefined,
  role_id: null,
  groups: 1,
};

const { Option } = Select;

@connect(({ admin, page }) => ({ ...admin, ...page }))
class Page extends PureComponent {
  columns = [
    {
      title: '账号ID',
      dataIndex: 'id',
      align: 'center',
    },
    {
      title: '昵称',
      dataIndex: 'nick',
      align: 'center',
    },
    {
      title: '账号',
      dataIndex: 'account',
      align: 'center',
    },
    {
      title: '角色',
      dataIndex: 'role_name',
      align: 'center',
    },
    {
      title: '最近登录IP',
      dataIndex: 'last_login_ip',
      align: 'center',
    },
    {
      title: '最后一次登录时间',
      render: item => <span>{moment.unix(item.last_login_time).format('YYYY-MM-DD HH:mm:ss')}</span>,
      align: 'center',
    },
    {
      title: '操作',
      align: 'center',
      render: (item) => (
        <>
          <a onClick={() => this.onCreate(item)}>编辑</a>
          <Divider type='vertical' />
          <Popconfirm title='是否删除用户' onConfirm={() => this.onDelete(item.id)}>
            <a>删除</a>
          </Popconfirm>
        </>
      ),
    },
  ];

  form = new FormCore({
    validateConfig: {
      account: [{ required: true, message: '请输入账号' }],
      role_id: [{ required: true, message: '请选择角色' }],
      passwd: (values) => { // dynamic validate config
        console.log(values, 'vlues');

        const { passwd } = values;
        if (passwd && passwd.length < 6) {
          console.log(passwd, 'asdfsadfs');
          return { type: "string", required: true, message: '请输入长度大于6个字符的密码' };
        }
      },
    },
  });

  componentDidMount() {
    const {
      dispatch,
    } = this.props;

    dispatch({
      type: 'page/init',
      payload: '/admin/user',
    });

    dispatch({
      type: 'admin/roleAll',
    })
  }

  onCreate = (item = defaultValues) => {
    const { roleList } = this.props;

    const onOk = (values, hide) => {
      this.form.validate(errors => {
        if (!errors) {
          this.props.dispatch({
            type: `page/${values.id ? 'update' : 'create'}`,
            payload: values,
            callback: () => {
              hide();
            },
          });
        }
      });
    };

    this.form.setValues(item);
    this.form.setValue('passwd', undefined); // 密码重置为空的状态
    if (item.account) {
      this.form.setStatus('account', 'preview');
    } else {
      this.form.setStatus('account', 'edit');
    }

    DialogForm.show({
      title: `${item.id ? '编辑' : '新增'}管理员`,
      width: 650,
      onOk,
      content: (
        <Form core={this.form} layout={{ label: 4 }}>
          <FormItem name="account" label="账号" required>
            <Input placeholder='请输入账号' />
          </FormItem>
          <FormItem name="passwd" label="密码">
            <Input placeholder='请输入密码' />
          </FormItem>
          <FormItem name="role_id" label="角色" required>
            <Select placeholder="请选择">
              {roleList.map(i => (
                <Option key={i.id} value={i.id}>
                  {i.role_name}
                </Option>
              ))}
            </Select>
          </FormItem>
        </Form>
      ),
    });
  };

  onDelete = (id) => {
    this.props.dispatch({
      type: 'page/delete',
      payload: id,
    });
  };

  render() {
    return (
      <PageTable
        title="管理员列表"
        columns={this.columns}
        createText='添加管理员'
        onCreate={() => this.onCreate()}
        form={
          <>
            <FormItem name="keyword" label="关键字">
              <Input placeholder='关键字查询' />
            </FormItem>
          </>
        }
      />
    );
  }
}

export default Page;
