import { authList, roleList, authTree, saveAuthTree } from 'services/api';
import { message } from 'antd';

export default {
  namespace: 'admin',

  state: {
    authList: [],
    roleList: [],
    authTree: [],
    seleAuthTree: [],
    roleAuthTree: [],
  },

  effects: {
    *authAll(_, { call, put }) {
      const { items } = yield call(authList);

      yield put({
        type: 'save',
        payload: {
          authList: items,
        },
      });
    },

    *seleAuthTree({ payload }, { put }) {
      yield put({
        type: 'save',
        payload: {
          seleAuthTree: payload,
        },
      });
    },

    *authTree(_, { call, put }) {
      const { items } = yield call(authTree);

      yield put({
        type: 'save',
        payload: {
          authTree: items,
        },
      });
    },

    *roleAuthTree(_, { call, put }) {
      const { items } = yield call(authTree);

      const loop = (list, parentId = 0, curList = []) => {
        list.forEach(item => {
          item.value = item.id;
          item.title = item.auth_name;
          item.key = `key-${item.id}`;
          item.pId = parentId;
          curList.push(item);
          if (item.children && item.children.length) {
            loop(item.children, item.id, curList);
          }
        });
        return curList;
      };

      yield put({
        type: 'save',
        payload: {
          roleAuthTree: loop(items),
        },
      });
    },

    *saveAuthTree({ payload }, { call }) {
      const makeTree = originTree => {
        const treeNode = [];
        originTree.forEach(item => {
          const subNode = { id: item.id };
          if (item.children && item.children.length > 0) {
            subNode.children = makeTree(item.children);
          }
          treeNode.push(subNode);
        });
        return treeNode;
      };

      const order = makeTree(payload);

      const data = {
        method: 'POST',
        body: {
          order,
        },
      };
      console.log('save order', data);

      const res = yield call(saveAuthTree, data);
      if (res) {
        message.success('保存成功');
      }
    },

    *roleAll(_, { call, put }) {
      const { items } = yield call(roleList);
      yield put({
        type: 'save',
        payload: {
          roleList: items,
        },
      });
    },
  },

  reducers: {
    save(state, { payload }) {
      return {
        ...state,
        ...payload,
      };
    },
  },
};
