import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Divider, Popconfirm, TreeSelect } from 'antd';
import { Form, FormCore, FormItem, Input, DialogForm } from 'antd-noform';
import { PageTable } from 'components';
import moment from 'moment';

const defaultValues = {
  id: undefined,
  role_name: undefined,
  role_auth: [],
  role_status: 1,
  level: undefined,
};
const { SHOW_ALL } = TreeSelect

@connect(({ admin, page }) => ({...admin, ...page }))
class Page extends PureComponent {
  columns = [
    {
      title: '账号ID',
      dataIndex: 'id',
      align: 'center',
    },
    {
      title: '名称',
      dataIndex: 'role_name',
      align: 'center',
    },
    {
      title: '角色权限',
      dataIndex: 'auth_name',
      align: 'center',
    },
    {
      title: '级别',
      dataIndex: 'level',
      align: 'center',
    },
    {
      title: '创建时间',
      render: item => <span>{moment.unix(item.created).format('YYYY-MM-DD HH:mm:ss')}</span>,
      align: 'center',
    },
    {
      title: '操作',
      align: 'center',
      render: (item) => (
        <>
          <a onClick={() => this.onCreate(item)}>编辑</a>
          {
            item.id !== 1 ? (
              <>
                <Divider type='vertical' />
                <Popconfirm title='是否删除用户' onConfirm={() => this.onDelete(item.id)}>
                  <a>删除</a>
                </Popconfirm>
              </>
             ):''
          }
        </>
      ),
    },
  ];

  form = new FormCore({
    validateConfig: {
      role_name: [{ required: true, message: '请输入角色名' }],
      role_auth: [{ required: true, message: '请选择权限' }],
    },
  });

  componentDidMount() {
    const {
      dispatch,
    } = this.props;

    dispatch({
      type: 'page/init',
      payload: '/admin/role',
    });

    dispatch({
      type: 'admin/authAll',
    });

    dispatch({
      type: 'admin/roleAuthTree',
    });  
  }

  onCreate = (item = defaultValues) => {

    const { dispatch, roleAuthTree } = this.props;
    const onOk = (values, hide) => {
      this.form.validate(errors => {
        if (!errors) {
          values.role_auth = onResetValue(values.role_auth,'addPId')
          dispatch({
            type: `page/${values.id ? 'update' : 'create'}`,
            payload: values,
            callback: () => {
              hide();
            },
          });
        }
      });
    };
    
    const onResetValue = (array,type) => {
      switch(type){
        case 'addPId':
        array.forEach(idX => {
          const curAuth = roleAuthTree.find(authItem => authItem.id === idX)
          if(curAuth && curAuth.pId && !array.find(idY => idY === curAuth.pId)){
            array.push(curAuth.pId)
          }
        })
        break
        case 'delPId':
        array.forEach(idX => {
          const curAuth = roleAuthTree.find(authItem => authItem.id === idX)
          if(curAuth && curAuth.pId && array.find(idY => idY === curAuth.pId)){
            array.splice(array.findIndex(idZ => idZ === curAuth.pId), 1)
          }
        })      
        break
        default:
        break
      }
      console.log('array',array)
      return array
    };

    this.form.setValues(item);
    console.log(this.form.getValues(),'role');
    const onChange = (value) => {
      dispatch({
        type: 'admin/seleAuthTree',
        payload: value,
      });
    };

    DialogForm.show({
      title: `${item.id ? '编辑' : '新增'}角色`,
      width: 650,
      onOk,
      content: (
        <Form core={this.form} layout={{ label: 4 }} hideRequiredMark>
          <FormItem name="role_name" label="群组名" required>
            <Input placeholder='请输入名称' />
          </FormItem>
          <FormItem name="role_auth" label="权限" required>
            <TreeSelect 
              treeData={roleAuthTree} 
              treeDataSimpleMode={{id:'key',pId:'pId',rootPId:0}}
              value={onResetValue(item.role_auth,'delPId')}
              placeholder='请输入权限名称'
              onChange={onChange}
              treeCheckable
              showCheckedStrategy={SHOW_ALL}
              allowClear
              treeNodeFilterProp='title'
            />
          </FormItem>
        </Form>
      ),
    });
  };

  onDelete = (id) => {
    this.props.dispatch({
      type: 'page/delete',
      payload: id,
    });
  };

  render() {
    return (
      <PageTable
        title="群组"
        columns={this.columns}
        createText='添加群组'
        onCreate={() => this.onCreate()}
        form={
          <>
            <FormItem name="keyword" label="关键字">
              <Input placeholder='关键字查询' />
            </FormItem>
          </>
        }
      />
    );
  }
}

export default Page;
