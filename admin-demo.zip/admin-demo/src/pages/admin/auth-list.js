import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Divider, Popconfirm, Layout, Tree, Button , Icon, Card} from 'antd';
import { Form, FormCore, FormItem, Input, DialogForm, Select } from 'antd-noform';
import { PageTable } from 'components';

const defaultValues = {
  id: undefined,
  auth_name: undefined,
  auth_type: undefined,
  auth_rules: undefined,
  auth_icon: undefined,
};

const { Option } = Select;
const {Sider, Content } = Layout;
const { TreeNode } = Tree;

@connect(({ admin, page }) => ({...admin, ...page }))
class Page extends PureComponent {

  form = new FormCore({
    validateConfig: {
      auth_name: [{ required: true, message: '请输入菜单名' }],
      auth_type: [{ required: true, message: '请选择类型' }],
      auth_rules: [{ required: true, message: '请输入地址' }],
    },
  });

  columns = [
    {
      title: '权限ID',
      dataIndex: 'id',
      align: 'center',
    },
    {
      title: '名称',
      dataIndex: 'auth_name',
      align: 'center',
    },
    {
      title: '图标',
      render: (item)=> <Icon type={item.auth_icon} />,
      align: 'center',
    },
    {
      title: 'url',
      dataIndex: 'auth_rules',
      align: 'center',
    },
    {
      title: '操作',
      align: 'center',
      render: (item) => (
        <>
          <a onClick={() => this.onCreate(item)}>编辑</a>
          <Divider type='vertical' />
          <Popconfirm title='是否删除' onConfirm={() => this.onDelete(item.id)}>
            <a>删除</a>
          </Popconfirm>
        </>
      ),
    },
  ];

  componentDidMount() {
    const {
      dispatch,
    } = this.props;

    dispatch({
      type: 'page/init',
      payload: '/admin/auth',
    })

    dispatch({
      type: 'admin/authTree',
    });
  }

  onCreate = (item = defaultValues) => {
    const onOk = (values, hide) => {
      this.form.validate(errors => {
        if (!errors) {
          this.props.dispatch({
            type: `page/${values.id ? 'update' : 'create'}`,
            payload: values,
            callback: () => {

              this.props.dispatch({
                type: 'admin/authTree',
              });
              hide();
            },
          });


        }
      });
    };

    this.form.setValues(item);

    DialogForm.show({
      title: `${item.id ? '编辑' : '新增'}权限`,
      width: 650,
      onOk,
      content: (
        <Form core={this.form} layout={{ label: 4 }} hideRequiredMark>
          <FormItem name="auth_name" label="权限名" required>
            <Input placeholder='请输入名称' />
          </FormItem>
          <FormItem name="auth_type" label="是否显示" required>
            <Select
              placeholder="请选择类型"
            >
              <Option key={1} value={1}>显示</Option>
              <Option key={2} value={2}>隐藏</Option>
            </Select>
          </FormItem>
          <FormItem name="auth_rules" label="地址" required>
            <Input placeholder='请输入地址' />
          </FormItem>
          <FormItem name="auth_icon" label="图标">
            <Input placeholder='请输入图标' />
          </FormItem>
        </Form>
      ),
    });
  };

  onDelete = (id) => {
    this.props.dispatch({
      type: 'page/delete',
      payload: id,
      callback: ()=>{
        this.props.dispatch({
          type: 'admin/authTree',
        })
      },
    });
  };

  onSort = () => {
    console.log('authTree',this.props.authTree);
    const { dispatch, authTree } = this.props;
    
    dispatch({
      type: 'admin/saveAuthTree',
      payload: authTree,
    })
  }

  render() { 
    const { authTree } = this.props;

    const loop = data => {
      return  data.map(item => {
        if (item.children && item.children.length) {
          return (
            <TreeNode key={item.id} title={item.auth_name}>
              {loop(item.children)}
            </TreeNode>
          );
        }
        return <TreeNode key={item.id} title={item.auth_name} />;
      })
    };

    const onDragEnter = info => {
      console.log(info);
      // expandedKeys 需要受控时设置
      // this.setState({
      //   expandedKeys: info.expandedKeys,
      // });
    };

    const onDrop = info => {
      console.log(info,'drop status');
      const dropKey = info.node.props.eventKey;
      const dragKey = info.dragNode.props.eventKey;
      const dropPos = info.node.props.pos.split('-');
      const dropPosition = info.dropPosition - Number(dropPos[dropPos.length - 1]);
  
      const dragLoop = (data, key, callback) => {
        key = Number(key); // 取出来的值为字符串类型，强转
        
        data.forEach((item, index, arr) => {
          
          if (item.id === key) {
            return callback(item, index, arr);
          }
          if (item.children) {
            return dragLoop(item.children, key, callback);
          }
        });
      };
      // const data = [...this.state.gData];
      const data = authTree;
  
      // Find dragObject
      let dragObj;
      dragLoop(data, dragKey, (item, index, arr) => {
        arr.splice(index, 1);
        dragObj = item;
      });

      if (!info.dropToGap) {
        // Drop on the content
        dragLoop(data, dropKey, item => {
          
          item.children = item.children || [];
          // where to insert 示例添加到尾部，可以是随意位置
          item.children.push(dragObj);
        });
      } else if (
        (info.node.props.children || []).length > 0 && // Has children
        info.node.props.expanded && // Is expanded
        dropPosition === 1 // On the bottom gap
      ) {
        dragLoop(data, dropKey, item => {
          item.children = item.children || [];
          // where to insert 示例添加到尾部，可以是随意位置
          item.children.unshift(dragObj);
        });
      } else {
        let ar;
        let i;
        dragLoop(data, dropKey, (item, index, arr) => {
          ar = arr;
          i = index;
        });
        
        if (dropPosition === -1) {
          ar.splice(i, 0, dragObj);
        } else {
          ar.splice(i + 1, 0, dragObj);
        }
      }
      
      this.props.dispatch({
        type: 'admin/save',
        payload: {
          authTree: [...data],
        },
      })
    }

    return (
      <Layout style={{ background: '#FFF'}}>
        <Layout style={{ padding: 24 }}>
          <Sider theme='light' width="60%" style={{background:'#F0F0F0', 'borderRight':'1px solid gray', padding:'20px'}}>
            <PageTable
              title="权限菜单列表"
              columns={this.columns}
              createText='添加菜单'
              onCreate={() => this.onCreate()}
            />
          </Sider>
          <Content style={{paddingLeft: 24}}>
            <Card title='权限排序' bordered={false}>
              <Form direction="horizontal">
                <div className="searchBtn">
                  <span><b>拖动</b> 排序决定菜单类型权限显示</span>
                  <Divider type='vertical' />
                  <Button type="primary" size="small" onClick={this.onSort}>
                保存排序
                  </Button>
                </div>
              </Form>
              <Content>
                <Tree
                  className="draggable-tree"
                  defaultExpandAll
                  showLine
                  draggable
                  blockNode
                  onDragEnter={onDragEnter}
                  onDrop={onDrop}
                >
                  {loop(authTree)}
                </Tree>
              </Content>
            </Card>

          </Content>

        </Layout>
      </Layout>
      )
    }
}

export default Page;
