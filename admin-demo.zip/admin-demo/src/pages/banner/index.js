import React, { PureComponent } from 'react';
import { connect } from 'dva';
import { Divider, Popconfirm, InputNumber } from 'antd';
import {
  Form,
  FormCore,
  FormItem,
  DialogForm,
  Switch,
  Select,
} from 'antd-noform';
import { PageTable, Image, StatusView, OssImage } from 'components';
import moment from 'moment';
import { handleUploadToData, dataToUpload } from '../../utils/utils';

const defaultValues = {
  id: undefined,
  type: 1,
  status: false,
  cover: undefined,
};

@connect(({ userList }) => ({ ...userList }))
class Page extends PureComponent {
  columns = [
    {
      title: 'ID',
      dataIndex: 'id',
      align: 'center',
    },
    {
      title: '封面',
      align: 'center',
      render: item => <Image src={item.cover} />,
    },
    {
      title: '启用',
      align: 'center',
      render: item => <StatusView status={item.status} />,
    },
    {
      title: '类型',
      align: 'center',
      render: item => item.type === 1 ? "首页" : "领养",
    },
    {
      title: '排序(越小越靠前)',
      dataIndex: 'sort',
      align: 'center',
    },
    {
      title: '修改时间',
      align: 'center',
      render: item => <span>{moment.unix(item.edit_time).format('YYYY-MM-DD HH:mm:ss')}</span>,
    },
    {
      title: '添加时间',
      align: 'center',
      render: item => <span>{moment.unix(item.created).format('YYYY-MM-DD HH:mm:ss')}</span>,
    },
    {
      title: '操作',
      align: 'center',
      width: 200,
      render: item => (
        <>
          <a onClick={() => this.onCreate(item)}>编辑</a>
          <Divider type="vertical" />
          <Popconfirm title="是否删除" onConfirm={() => this.onDelete(item.id)}>
            <a>删除</a>
          </Popconfirm>
        </>
      ),
    },
  ];

  form = new FormCore({
    validateConfig: {
      type: [{ required: true, message: '请选择banner类型' }],
      cover: [{ required: true, message: '请上传封面' }],
      address: [{ required: true, message: '请填写跳转地址' }],
    },
  });

  defaultFileList = [];

  defaultBanner = [];

  componentDidMount() {
    const { dispatch } = this.props;

    dispatch({
      type: 'page/init',
      payload: '/admin/banner',
    });
  }

  // 上传成功的回调，将数据转为ossUrl
  onUploadSuccess = (file, key, core) => {
    core.setValue(key, file)
  }

  onCreate = (item = defaultValues) => {
    const onOk = (values, hide) => {
      this.form.validate(errors => {
        if (!errors) {
          values.cover = handleUploadToData(values.cover, 'string');
          values.status = values.status ? 1 : 2

          this.props.dispatch({
            type: `page/${values.id ? 'update' : 'create'}`,
            payload: values,
            callback: () => {
              hide();
            },
          });
        }
      });
    };

    this.form.setValues(item);
    this.form.setValues({
      cover: dataToUpload(item.cover, 'string'),
      status: item.status === 1,
    })

    DialogForm.show({
      title: '编辑信息',
      width: 800,
      onOk,
      forceRender: true,
      content: (
        <Form core={this.form} layout={{ label: 4 }}>
          <FormItem name='cover' label='封面' required layout={{ label: 4, control: 10 }} onSuccess={(file) => this.onUploadSuccess(file, 'cover', this.form)}>
            <OssImage listLength={1} />
          </FormItem>
          <FormItem name="status" label="是否启用" required>
            <Switch checkedChildren="开" unCheckedChildren="关" />
          </FormItem>
          <FormItem name="sort" label="排序">
            <InputNumber placeholder="越小越前" />
          </FormItem>
          <FormItem name="type" label="类型">
            <Select
              placeholder="越小越前"
              options={[
                { value: 1, key: 1, label: "首页" },
                { value: 2, key: 2, label: "领养" },
              ]}
            />
          </FormItem>
        </Form>
      ),
    });
  };

  onDelete = id => {
    this.props.dispatch({
      type: 'page/delete',
      payload: id,
    });
  };

  render() {
    return (
      <PageTable
        title="Banner 列表"
        columns={this.columns}
        createText="新增banner"
        rowKey="id"
        onCreate={() => this.onCreate()}
      />
    );
  }
}

export default Page;
