import { resolve } from 'path';

export default {
  alias: {
    'components': resolve(__dirname, 'src/components'),
    'services': resolve(__dirname, 'src/services'),
    'layouts': resolve(__dirname, 'src/layouts'),
    'utils': resolve(__dirname, 'src/utils'),
    'antd-noform': resolve(__dirname, 'src/utils/noform'),
  },
  extraBabelPlugins: [
    ['wrapper', {}],
  ],
  plugins: [
    ['umi-plugin-react', {
      antd: true,
      dva: {
        hmr: true,
        dynamicImport: true,
      },
      locale: {
        enable: true, // default false
        default: 'zh-CN', // default zh-CN
        baseNavigator: true, // default true, when it is true, will use `navigator.language` overwrite default
      },
      targets: {
        ie: 9,
      },
      dynamicImport: true,
      routes: {
        exclude: [/(.*)\/(assets|components|models|services)\/(.*)/],
      },
    }],
  ],
  hash: true,
  targets: {
    ie: 11,
  },
  ignoreMomentLocale: true,
}
